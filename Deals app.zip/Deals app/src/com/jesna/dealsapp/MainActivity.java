package com.jesna.dealsapp;



import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.app.Activity;

public class MainActivity extends Activity {
	// Declare Tab Variable
	ActionBar.Tab Top, Popular;
	Fragment fragmentTab1 = new FragmentTab1();
	Fragment fragmentTab2 = new FragmentTab2();
	

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		ActionBar actionBar = getActionBar();

		// Hide Actionbar Icon
		actionBar.setDisplayShowHomeEnabled(false);

		// Hide Actionbar Title
		actionBar.setDisplayShowTitleEnabled(false);

		// Create Actionbar Tabs
		actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

		// Set Tab Icon and Titles
		Top = actionBar.newTab().setText("Top");
		Popular= actionBar.newTab().setText("Popular");
		

		// Set Tab Listeners
		Top.setTabListener(new TabListener(fragmentTab1));
		Popular.setTabListener(new TabListener(fragmentTab2));
	

		// Add tabs to actionbar
		actionBar.addTab(Top);
		actionBar.addTab(Popular);
	
	}
}
