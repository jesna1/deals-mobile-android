package com.jesna.dealsapp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Fragment;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

public class FragmentTab2 extends Fragment {
	LazyImageLoadAdapter1 adapter;
	ListView name;
	ProgressDialog progressDialog;
	 final String deallist="http://www.desidime.com/api/v1/premium_deals/list";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragmenttab2, container, false);
        name = (ListView)rootView.findViewById(R.id.incomelv1);
        String deallist="http://www.desidime.com/api/v1/premium_deals/list";
        new JSonParesr().execute(deallist);
        
        
        
        return rootView;
    }
	private static String convertInputStreamToString(InputStream inputStream)
			throws IOException {
		BufferedReader bufferedReader = new BufferedReader(
				new InputStreamReader(inputStream));
		System.out.println("eeeediscr");
		String line = "";
		String result = "";
		while ((line = bufferedReader.readLine()) != null)
			result += line;

		inputStream.close();
		return result;

	}


  public static String Helpget(String url) {
		InputStream inputStream = null;
		Bitmap bitmap;
		ImageView imagy;
		String result = "";
		try {
			
			JSONObject json = new JSONObject();
			System.out.println("dddiscprtion");
			
			
			HttpPost post = new HttpPost(url);
			post.setHeader(new BasicHeader(HTTP.CONTENT_TYPE,
					"application/json"));
			post.setHeader("Content-type", "application/json");
			post.setHeader("Accept", "application/json");
			post.setHeader("Accept", "text/javascript");
			post.setEntity(new StringEntity(json.toString(), "UTF-8"));

			// create HttpClient
			HttpClient httpclient = new DefaultHttpClient();

			// make GET request to the given URL
			HttpResponse httpResponse = httpclient.execute(post);

			// receive response as inputStream
			inputStream = httpResponse.getEntity().getContent();

			// convert inputstream to string
			if (inputStream != null)

				result = convertInputStreamToString(inputStream);
			else
				result = "Did not work!";

		} catch (Exception e) {
			Log.d("InputStream", e.getLocalizedMessage());
		}

		return result;
	}
private class JSonParesr extends AsyncTask<String, Void, String> {

	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();

		if (progressDialog == null)
			progressDialog = ProgressDialog.show(getActivity(), "",
					("Loading Please wait...."));


	}

	@Override
	protected String doInBackground(String... urls) {

		return Helpget(urls[0]);
	}

	// onPostExecute displays the results of the AsyncTask.
	@Override
	protected void onPostExecute(String result) {
		System.out.println("FFFdisc");
		// Toast.makeText(getBaseContext(), "Received!",
		// Toast.LENGTH_LONG).show();
		// etResponse.setText(result);
		Log.d("receivedSSSdisc", "" + result);
	
		try {

			if (result.trim().length() > 0) {
				JSONObject json = new JSONObject(result);
				String errorstr=json.getString("errorstr");
				ArrayList<String>idarray=new ArrayList<String>();
				ArrayList<String>titlearray=new ArrayList<String>();
				ArrayList<String>discriptionarray=new ArrayList<String>();
				ArrayList<String>imagearray=new ArrayList<String>();
			if (errorstr.equals("Success")) {
				
				
				JSONObject json2 = json.getJSONObject("result");
		
					
				
					
					JSONArray top = json2.getJSONArray("popular");
//					
			
					
					
					
				for (int i = 0; i < top.length(); i++) {
//						
						JSONObject json1 = top.getJSONObject(i);	
//						
						String id = json1.getString("id");	
						String title = json1.getString("title");
						
						String off_percent = json1.getString("off_percent");
						String store = json1.getString("store");
						String current_price = json1.getString("current_price");
						String original_price = json1.getString("original_price");
						String posted_user_id = json1.getString("posted_user_id");
						String pic_thumb = json1.getString("pic_thumb");
						String deal_detail = json1.getString("deal_detail");
						//String posted_user_id = json1.getString("posted_user_id");
						
						idarray.add(id);
						titlearray.add(title);
						discriptionarray.add(deal_detail);
						imagearray.add(pic_thumb);
						
						
						
				}
						
			
		
						
						
						String[] idvalarray = idarray.toArray(new String[idarray.size()]);	
						
						String[] titlevalarray = titlearray.toArray(new String[titlearray.size()]);	
						String[] discvalarray = discriptionarray.toArray(new String[discriptionarray.size()]);	
						String[] imgvalarray = imagearray.toArray(new String[imagearray.size()]);	
						
						
						progressDialog.dismiss();
						 adapter=new LazyImageLoadAdapter1(getActivity(), idvalarray,titlevalarray,discvalarray,imgvalarray);
						  name.setAdapter(adapter);	
						
	
			}
				else {
					progressDialog.dismiss();
					Toast.makeText(getActivity(),
							"Failure.",
							Toast.LENGTH_SHORT).show();
				}
				
				
				System.out.println("hhhdisc");
			

				progressDialog.dismiss();
			
				
			
			} else {
//				if (progressDialog != null && progressDialog.isShowing())
//					progressDialog.dismiss();
				progressDialog.dismiss();
				Toast.makeText(getActivity(),
						"Please Check your Internet Connection.",
						Toast.LENGTH_SHORT).show();
			}
		} catch (JSONException e) {

			if (progressDialog != null && progressDialog.isShowing())
				progressDialog.dismiss();
			e.printStackTrace();
		}
	}  


}
}