package com.jesna.dealsapp;




import java.util.ArrayList;






import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Html;
import android.text.Spanned;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

//Adapter class extends with BaseAdapter and implements with OnClickListener 
public class LazyImageLoadAdapter1 extends BaseAdapter {

	  TextView authrview;
	  ImageLoader imageLoader;
 // private String[] data;
  //private Activity activity;
  private String[] data1;
  private String[] authrdata;
  private String[] replays;

 // private String[] allpostnbrarr;
  
  //private String[] lstcmnt;
  
//  private String[] createdon;
  private String[] createdby;
  
  
  
  
  DisplayMetrics metrics;
  String language;
//  int aa;
 float scale ;
  private static LayoutInflater inflater=null;
 // public ImageLoader imageLoader; 
  Context context;

Activity activity1;

ArrayList<String> specificpositions=new ArrayList<String>();




  public LazyImageLoadAdapter1(Activity activity,
			String[] authorarray, String[] posteddatearray,
			String[] repliesarray, String[] createdbyuserarray
			) {
  	
  	
  	
  	
  	  SharedPreferences    settings11 =activity. getSharedPreferences("UserInfo", 0);
	    	language=settings11.getString("Language","").toString();
	     scale =activity.getResources().getDisplayMetrics().density;
	     
	     activity1=activity;
	     data1=posteddatearray;
	 // data=namesArr;
     
      authrdata=authorarray;
      
      replays=repliesarray;
     // allpostnbrarr=viewsaarray;
     // lstcmnt=lastcommentarray;
      
      createdby=createdbyuserarray;
     // createdon=createdondatearray;
      
      
      
     
      
      
      inflater = (LayoutInflater)activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
  	
  	
		// TODO Auto-generated constructor stub
	}



	public int getCount() {
      return data1.length;
  }

  public Object getItem(int position) {
      return position;
  }

  public long getItemId(int position) {
      return position;
  }
  
  /********* Create a holder Class to contain inflated xml file elements *********/
  public static class ViewHolder{
       
//      public TextView text;
      public TextView dateposted,post;
   
      public ImageView image;
      //LinearLayout right;
  
      ImageView profileview;
  }
  
  public View getView(final int position, View convertView, ViewGroup parent) {
  	specificpositions.clear();
      View vi=convertView;
      final ViewHolder holder;
      
      if(convertView==null){
//if (language.equals("ar")) {
//	 vi = inflater.inflate(R.layout.amountitemarb, null);
//	    	}
//else {
	  vi = inflater.inflate(R.layout.replayitem, null);
//}
          /****** Inflate tabitem.xml file for each row ( Defined below ) *******/
        
          
          
           
          /****** View Holder Object to contain tabitem.xml file elements ******/

          holder = new ViewHolder();
          holder.dateposted = (TextView) vi.findViewById(R.id.nameitem);
          holder.post = (TextView) vi.findViewById(R.id.nameitem1);
       
        
          holder.profileview=(ImageView)vi.findViewById(R.id.ImageView);
          
        
          
          
        
         metrics =vi.getResources().getDisplayMetrics();
         
          int listwidth = (int) (100*scale + 0.5f);  
          int width = (metrics.widthPixels-listwidth)/2;   
         //holder.text.setWidth(width);
       //   holder.dateposted.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
          
         // holder.text1.setWidth(width);
        //  holder.authrview.setWidth(width);
          
         // holder.datesview.setWidth(width);
         // holder.post.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
       //   holder.createdon.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);  
        //  holder.author.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        //  holder.text.setPadding(25, 10, 30, 0); 
         
          
          
        
        //  holder.text1.setPadding(0, 10, 85, 0); 
          //holder.text1.setPadding(0, 10,75, 0); 
          //holder.text1.setBackgroundColor(Color.CYAN);
        //  holder.text.setBackgroundColor(Color.MAGENTA);
       
          
          
          
         /************  Set holder with LayoutInflater ************/
          vi.setTag( holder );
      }
      else 
          holder=(ViewHolder)vi.getTag();
     

      	
      	
      	
      	
      	

      
     


	
      	
         	
     
     		 


		  	 
		
		  	 	 
		  	 	 
		  	 	 
		  	 	 
		  	 	 
		  	 	 
		  	 	 
		  	 	 

     
	
	  			holder.dateposted.setText(data1[position]);
	  			
	  			holder.dateposted.setTextSize(17);
	  			//holder.dateposted.setTextColor(Color.parseColor("#ffffff"));
	  			
	  			Spanned dealdisc=Html.fromHtml(replays[position]);
	  		  holder.post .setText(dealdisc);
	            //holder.post.setText(data[position]);
	  			//holder.LAY.setBackgroundColor(Color.parseColor("#fcf6cc"));
	  		//	holder.text.setBackgroundColor(Color.TRANSPARENT);	
	  			holder.dateposted.setBackgroundColor(Color.TRANSPARENT);	
	  			//holder.left.setBackgroundResource(R.drawable.textviewbackgrndtableleft);
	  			//holder.text.setLayoutParams(params);
	  			holder.dateposted.setPadding(15, 10, 10, 10);
	  			holder.dateposted.setGravity(Gravity.CENTER_VERTICAL);
	  		

     	  String createdbystring=createdby[position];
     	  //if (!createdbystring.equals("")) {
     		// holder. author.setText("by "+createdby[position]);
     		 
  		
      		ImageView image1 = holder.profileview;
			//image1.setRotation(90);
			imageLoader = new ImageLoader(context);
// image1.setScaleType(ScaleType.FIT_XY);
			imageLoader.DisplayImage(createdbystring, image1);
		//}





      
      return vi;
  }
  
  
  
  




	public void setNotifyOnChange(boolean b) {
		// TODO Auto-generated method stub
		
	}



	public void clear() {
		// TODO Auto-generated method stub
		
	}
	
  

      
   


}